export type ModelProvider = "openai" | "mistral" | "openrouter" | "custom"
