export type FileItemChunk = {
  content: string
  tokens: number
}
