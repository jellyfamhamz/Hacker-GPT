export type ContentType = "chats" | "prompts" | "files" | "tools" | "models"
