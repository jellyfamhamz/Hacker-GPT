export type EnvKey = "OPENAI_API_KEY" | "MISTRAL_API_KEY"
