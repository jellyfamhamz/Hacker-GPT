export type Sharing = "private" | "public" | "unlisted"
